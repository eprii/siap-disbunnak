// SIAP_REGISTER_SCROLL_LIMIT_FIX
import 'package:flutter/material.dart';

import '../../services/auth_service.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  static const String _logoAsset = 'assets/images/logo/LOGO_KALSEL.png';

  static const Color _panelColor = Color(0xFFF0EDDE);
  static const Color _primaryDark = Color(0xFF412D00);
  static const Color _greenDark = Color(0xFF43532B);

  static const double _waveHeight = 118;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _agreeTerms = false;
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _submitRegister() async {
    FocusScope.of(context).unfocus();

    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    if (!_agreeTerms) {
      _showMessage('Anda harus menyetujui Persyaratan & Ketentuan.');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await AuthService.instance.register(
        namaLengkap: _nameController.text,
        email: _emailController.text,
        password: _passwordController.text,
      );

      if (!mounted) return;

      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext dialogContext) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            title: const Text(
              'Registrasi Berhasil',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: const Text(
              'Akun berhasil dibuat. Silakan login menggunakan email '
              'atau username Anda.',
              style: TextStyle(fontSize: 13),
            ),
            actions: <Widget>[
              FilledButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                },
                style: FilledButton.styleFrom(
                  backgroundColor: _primaryDark,
                ),
                child: const Text('KE LOGIN'),
              ),
            ],
          );
        },
      );

      if (!mounted) return;
      Navigator.of(context).pop();
    } on AuthServiceException catch (error) {
      if (!mounted) return;
      _showMessage(error.message);
    } catch (_) {
      if (!mounted) return;
      _showMessage('Registrasi gagal. Silakan coba kembali.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message), backgroundColor: Colors.red.shade700),
      );
  }

  @override
  Widget build(BuildContext context) {
    final bool keyboardVisible = MediaQuery.viewInsetsOf(context).bottom > 0;

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final bool compactHeight = constraints.maxHeight < 760;

            return Stack(
              fit: StackFit.expand,
              clipBehavior: Clip.none,
              children: [
                const ColoredBox(color: Colors.white),

                Positioned(
                  top: 12,
                  bottom: 18,
                  left: 16,
                  right: 16,
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 420),
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: _panelColor,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(30),
                          child: AutofillGroup(
                            child: Form(
                              key: _formKey,
                              child: SingleChildScrollView(
                                keyboardDismissBehavior:
                                    ScrollViewKeyboardDismissBehavior.manual,
                                physics: const ClampingScrollPhysics(),
                                padding: EdgeInsets.fromLTRB(
                                  34,
                                  compactHeight ? 34 : 52,
                                  34,
                                  keyboardVisible ? 28 : _waveHeight + 22,
                                ),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Center(
                                      child: Image.asset(
                                        _logoAsset,
                                        width: compactHeight ? 62 : 70,
                                        height: compactHeight ? 74 : 84,
                                        fit: BoxFit.contain,
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                              return Icon(
                                                Icons.account_balance_rounded,
                                                size: compactHeight ? 58 : 66,
                                                color: _greenDark,
                                              );
                                            },
                                      ),
                                    ),
                                    SizedBox(height: compactHeight ? 8 : 10),
                                    const Text(
                                      'Buat Akun',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                        color: Color.fromARGB(255, 0, 0, 0),
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    const Text(
                                      'Lengkapi data diri anda untuk\n'
                                      'membuat akun baru.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 16,
                                        height: 1.30,
                                      ),
                                    ),
                                    SizedBox(height: compactHeight ? 20 : 24),
                                    _buildField(
                                      label: 'Masukkan nama lengkap',
                                      controller: _nameController,
                                      hintText: 'Nama Lengkap Anda',
                                      icon: Icons.person_add_alt_1_outlined,
                                      textInputAction: TextInputAction.next,
                                      autofillHints: const [AutofillHints.name],
                                      validator: (value) {
                                        final String text = value?.trim() ?? '';

                                        if (text.isEmpty) {
                                          return 'Nama lengkap wajib diisi';
                                        }

                                        if (text.length < 3) {
                                          return 'Nama lengkap terlalu pendek';
                                        }

                                        return null;
                                      },
                                    ),
                                    _buildField(
                                      label: 'Masukkan email',
                                      controller: _emailController,
                                      hintText: 'Email',
                                      icon: Icons.email_outlined,
                                      keyboardType: TextInputType.emailAddress,
                                      textInputAction: TextInputAction.next,
                                      autofillHints: const [
                                        AutofillHints.email,
                                      ],
                                      validator: (value) {
                                        final String text = value?.trim() ?? '';

                                        if (text.isEmpty) {
                                          return 'Email wajib diisi';
                                        }

                                        if (!RegExp(
                                          r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                                        ).hasMatch(text)) {
                                          return 'Format email tidak valid';
                                        }

                                        return null;
                                      },
                                    ),
                                    _buildPasswordField(
                                      label: 'Masukkan kata sandi',
                                      controller: _passwordController,
                                      obscure: _obscurePassword,
                                      onToggle: () {
                                        setState(() {
                                          _obscurePassword = !_obscurePassword;
                                        });
                                      },
                                      textInputAction: TextInputAction.next,
                                      autofillHints: const [
                                        AutofillHints.newPassword,
                                      ],
                                      validator: (value) {
                                        final String text = value ?? '';

                                        if (text.isEmpty) {
                                          return 'Kata sandi wajib diisi';
                                        }

                                        if (text.length < 8) {
                                          return 'Kata sandi minimal 8 karakter';
                                        }

                                        if (!RegExp(
                                              r'[A-Za-z]',
                                            ).hasMatch(text) ||
                                            !RegExp(r'\d').hasMatch(text)) {
                                          return 'Gunakan kombinasi huruf dan angka';
                                        }

                                        return null;
                                      },
                                    ),
                                    _buildPasswordField(
                                      label: 'Konfirmasi kata sandi',
                                      controller: _confirmPasswordController,
                                      obscure: _obscureConfirmPassword,
                                      onToggle: () {
                                        setState(() {
                                          _obscureConfirmPassword =
                                              !_obscureConfirmPassword;
                                        });
                                      },
                                      textInputAction: TextInputAction.done,
                                      autofillHints: const [
                                        AutofillHints.newPassword,
                                      ],
                                      onFieldSubmitted: (_) {
                                        if (!_isLoading) {
                                          _submitRegister();
                                        }
                                      },
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Konfirmasi kata sandi wajib diisi';
                                        }

                                        if (value != _passwordController.text) {
                                          return 'Konfirmasi kata sandi tidak sama';
                                        }

                                        return null;
                                      },
                                    ),
                                    const SizedBox(height: 1),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Checkbox(
                                          value: _agreeTerms,
                                          visualDensity: VisualDensity.compact,
                                          onChanged: _isLoading
                                              ? null
                                              : (value) {
                                                  setState(() {
                                                    _agreeTerms =
                                                        value ?? false;
                                                  });
                                                },
                                        ),
                                        const Expanded(
                                          child: Wrap(
                                            crossAxisAlignment:
                                                WrapCrossAlignment.center,
                                            children: [
                                              Text(
                                                'Saya menyetujui ',
                                                style: TextStyle(fontSize: 13),
                                              ),
                                              Text(
                                                'Persyaratan & Ketentuan',
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.blue,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 9),
                                    SizedBox(
                                      height: 44,
                                      child: FilledButton(
                                        onPressed: _isLoading
                                            ? null
                                            : _submitRegister,
                                        style: FilledButton.styleFrom(
                                          backgroundColor: _primaryDark,
                                          disabledBackgroundColor: _primaryDark
                                              .withOpacity(0.55),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              22,
                                            ),
                                          ),
                                        ),
                                        child: _isLoading
                                            ? const SizedBox(
                                                width: 20,
                                                height: 20,
                                                child:
                                                    CircularProgressIndicator(
                                                      strokeWidth: 2.1,
                                                      color: Colors.white,
                                                    ),
                                              )
                                            : const Text(
                                                'Register',
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                      ),
                                    ),
                                    const SizedBox(height: 20),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: 
                                      [
                                        const Text(
                                          'Sudah punya akun? ',
                                          style: TextStyle(fontSize: 17),
                                        ),
                                        InkWell(
                                          onTap: _isLoading
                                              ? null
                                              : () {
                                                  Navigator.of(context).pop();
                                                },
                                          child: const Text(
                                            'Login',
                                            style: TextStyle(
                                              fontSize: 17,
                                              color: Colors.blue,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                AnimatedPositioned(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOutCubic,
                  left: 0,
                  right: 0,
                  bottom: keyboardVisible ? -(_waveHeight + 18) : 0,
                  height: _waveHeight,
                  child: const IgnorePointer(
                    child: CustomPaint(painter: _RegisterBottomWavePainter()),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildField({
    required String label,
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    required TextInputAction textInputAction,
    required String? Function(String?) validator,
    TextInputType? keyboardType,
    Iterable<String>? autofillHints,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13.5)),
          const SizedBox(height: 4),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            textInputAction: textInputAction,
            autofillHints: autofillHints,
            scrollPadding: const EdgeInsets.only(bottom: 96),
            decoration: _inputDecoration(hintText: hintText, prefixIcon: icon),
            validator: validator,
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordField({
    required String label,
    required TextEditingController controller,
    required bool obscure,
    required VoidCallback onToggle,
    required TextInputAction textInputAction,
    required String? Function(String?) validator,
    Iterable<String>? autofillHints,
    ValueChanged<String>? onFieldSubmitted,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13.5)),
          const SizedBox(height: 4),
          TextFormField(
            controller: controller,
            obscureText: obscure,
            textInputAction: textInputAction,
            autofillHints: autofillHints,
            scrollPadding: const EdgeInsets.only(bottom: 96),
            onFieldSubmitted: onFieldSubmitted,
            decoration: _inputDecoration(
              hintText: label,
              prefixIcon: Icons.lock_outline,
              suffix: IconButton(
                tooltip: obscure
                    ? 'Tampilkan kata sandi'
                    : 'Sembunyikan kata sandi',
                onPressed: onToggle,
                icon: Icon(
                  obscure
                      ? Icons.visibility_rounded
                      : Icons.visibility_off_rounded,
                  color: Colors.black,
                ),
              ),
            ),
            validator: validator,
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration({
    required String hintText,
    required IconData prefixIcon,
    Widget? suffix,
  }) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: Colors.black38),
      prefixIcon: Icon(prefixIcon, size: 19, color: Colors.black54),
      suffixIcon: suffix,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(21),
        borderSide: const BorderSide(color: Colors.black),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(21),
        borderSide: const BorderSide(color: _greenDark, width: 1.6),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(21),
        borderSide: const BorderSide(color: Colors.red),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(21),
        borderSide: const BorderSide(color: Colors.red, width: 1.6),
      ),
    );
  }
}

class _RegisterBottomWavePainter extends CustomPainter {
  const _RegisterBottomWavePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Paint rearPaint = Paint()..color = const Color(0xFF72805A);

    final Path rearPath = Path()
      ..moveTo(0, size.height * 0.40)
      ..cubicTo(
        size.width * 0.20,
        size.height * 0.36,
        size.width * 0.34,
        size.height * 0.48,
        size.width * 0.50,
        size.height * 0.75,
      )
      ..cubicTo(
        size.width * 0.66,
        size.height * 0.97,
        size.width * 0.81,
        size.height * 0.47,
        size.width,
        size.height * 0.39,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(rearPath, rearPaint);

    final Paint frontPaint = Paint()..color = const Color(0xFF43532B);

    final Path frontPath = Path()
      ..moveTo(0, size.height * 0.31)
      ..cubicTo(
        size.width * 0.22,
        size.height * 0.29,
        size.width * 0.35,
        size.height * 0.43,
        size.width * 0.50,
        size.height * 0.80,
      )
      ..cubicTo(
        size.width * 0.65,
        size.height,
        size.width * 0.79,
        size.height * 0.42,
        size.width,
        size.height * 0.31,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(frontPath, frontPaint);
  }

  @override
  bool shouldRepaint(covariant _RegisterBottomWavePainter oldDelegate) {
    return false;
  }
}
