// SIAP_LOGIN_SCROLL_LIMIT_FIX
import 'package:flutter/material.dart';

import '../../services/auth_service.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  static const String _logoAsset = 'assets/images/logo/LOGO_KALSEL.png';

  static const Color _panelColor = Color(0xFFF0EDDE);
  static const Color _primaryDark = Color(0xFF412D00);
  static const Color _greenDark = Color(0xFF43532B);

  static const double _waveHeight = 148;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _identifierController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _isLoading = false;

  @override
  void dispose() {
    _identifierController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submitLogin() async {
    FocusScope.of(context).unfocus();

    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await AuthService.instance.login(
        identifier: _identifierController.text,
        password: _passwordController.text,
        rememberMe: _rememberMe,
      );
    } on AuthServiceException catch (error) {
      if (!mounted) return;
      _showMessage(error.message);
    } catch (_) {
      if (!mounted) return;
      _showMessage('Login gagal. Silakan coba kembali.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message), backgroundColor: Colors.red.shade700),
      );
  }

  @override
  Widget build(BuildContext context) {
    final bool keyboardVisible = MediaQuery.viewInsetsOf(context).bottom > 0;

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final bool compactHeight = constraints.maxHeight < 700;

            return Stack(
              fit: StackFit.expand,
              children: [
                const ColoredBox(color: Colors.white),

                Positioned.fill(
                  top: 12,
                  bottom: 18,
                  left: 16,
                  right: 16,
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 420),
                      child: SizedBox.expand(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: _panelColor,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: AutofillGroup(
                              child: Form(
                                key: _formKey,
                                child: SingleChildScrollView(
                                  keyboardDismissBehavior:
                                      ScrollViewKeyboardDismissBehavior.manual,
                                  physics: const ClampingScrollPhysics(),
                                  padding: EdgeInsets.fromLTRB(
                                    34,
                                    compactHeight ? 34 : 52,
                                    34,
                                    keyboardVisible ? 28 : _waveHeight + 22,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      Center(
                                        child: Image.asset(
                                          _logoAsset,
                                          width: compactHeight ? 62 : 70,
                                          height: compactHeight ? 74 : 84,
                                          fit: BoxFit.contain,
                                          errorBuilder:
                                              (context, error, stackTrace) {
                                                return Icon(
                                                  Icons.account_balance_rounded,
                                                  size: compactHeight ? 72 : 82,
                                                  color: Color.fromARGB(255, 0, 0, 0),
                                                );
                                              },
                                        ),
                                      ),
                                      SizedBox(height: compactHeight ? 18 : 23),
                                      const Text(
                                        'Dinas Perkebunan dan Peternakan\n'
                                        'Provinsi Kalimantan Selatan',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          height: 1.35,
                                          color: Colors.black87,
                                        ),
                                      ),
                                      SizedBox(height: compactHeight ? 44 : 52),
                                      const Text(
                                        'Masukkan email atau username',
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.black,
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                      TextFormField(
                                        controller: _identifierController,
                                        textInputAction: TextInputAction.next,
                                        scrollPadding: const EdgeInsets.only(
                                          bottom: 96,
                                        ),
                                        autofillHints: const [
                                          AutofillHints.username,
                                          AutofillHints.email,
                                        ],
                                        decoration: _inputDecoration(
                                          hintText: 'Email atau username',
                                          prefixIcon: Icons.person_outline,
                                        ),
                                        validator: (value) {
                                          if (value == null ||
                                              value.trim().isEmpty) {
                                            return 'Email atau username wajib diisi';
                                          }

                                          return null;
                                        },
                                      ),
                                      const SizedBox(height: 17),
                                      const Text(
                                        'Masukkan kata sandi',
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.black,
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                      TextFormField(
                                        controller: _passwordController,
                                        obscureText: _obscurePassword,
                                        textInputAction: TextInputAction.done,
                                        scrollPadding: const EdgeInsets.only(
                                          bottom: 96,
                                        ),
                                        autofillHints: const [
                                          AutofillHints.password,
                                        ],
                                        onFieldSubmitted: (_) {
                                          if (!_isLoading) {
                                            _submitLogin();
                                          }
                                        },
                                        decoration: _inputDecoration(
                                          hintText: 'Kata sandi',
                                          prefixIcon: Icons.lock_outline,
                                          suffix: IconButton(
                                            tooltip: _obscurePassword
                                                ? 'Tampilkan kata sandi'
                                                : 'Sembunyikan kata sandi',
                                            onPressed: () {
                                              setState(() {
                                                _obscurePassword =
                                                    !_obscurePassword;
                                              });
                                            },
                                            icon: Icon(
                                              _obscurePassword
                                                  ? Icons.visibility_rounded
                                                  : Icons
                                                        .visibility_off_rounded,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'Kata sandi wajib diisi';
                                          }

                                          return null;
                                        },
                                      ),
                                      const SizedBox(height: 10),
                                      Row(
                                        children: [
                                          Checkbox(
                                            value: _rememberMe,
                                            visualDensity:
                                                VisualDensity.compact,
                                            onChanged: _isLoading
                                                ? null
                                                : (value) {
                                                    setState(() {
                                                      _rememberMe =
                                                          value ?? false;
                                                    });
                                                  },
                                          ),
                                          
                                          const Text(
                                            'Remember me',
                                            style: TextStyle(fontSize: 15),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 14),
                                      SizedBox(
                                        height: 46,
                                        child: FilledButton(
                                          onPressed: _isLoading
                                              ? null
                                              : _submitLogin,
                                          style: FilledButton.styleFrom(
                                            backgroundColor: _primaryDark,
                                            disabledBackgroundColor:
                                                _primaryDark.withOpacity(0.55),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(23),
                                            ),
                                          ),
                                          child: _isLoading
                                              ? const SizedBox(
                                                  width: 21,
                                                  height: 21,
                                                  child:
                                                      CircularProgressIndicator(
                                                        strokeWidth: 2.2,
                                                        color: Colors.white,
                                                      ),
                                                )
                                              : const Text(
                                                  'Login',
                                                  style: TextStyle(
                                                    fontSize: 19,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          const Text(
                                            'Belum punya akun? ',
                                            style: TextStyle(fontSize: 17),
                                          ),
                                          InkWell(
                                            onTap: _isLoading
                                                ? null
                                                : () {
                                                    Navigator.of(
                                                      context,
                                                    ).pushNamed('/register');
                                                  },
                                            child: const Text(
                                              'Register',
                                              style: TextStyle(
                                                fontSize: 17,
                                                color: Colors.blue,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                AnimatedPositioned(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOutCubic,
                  left: 0,
                  right: 0,
                  bottom: keyboardVisible ? -(_waveHeight + 18) : 0,
                  height: _waveHeight,
                  child: const IgnorePointer(
                    child: CustomPaint(painter: _LoginBottomWavePainter()),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  InputDecoration _inputDecoration({
    required String hintText,
    required IconData prefixIcon,
    Widget? suffix,
  }) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: Colors.black38),
      prefixIcon: Icon(prefixIcon, size: 20, color: Colors.black54),
      suffixIcon: suffix,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(22),
        borderSide: const BorderSide(color: Colors.black),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(22),
        borderSide: const BorderSide(color: _greenDark, width: 1.7),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(22),
        borderSide: const BorderSide(color: Colors.red),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(22),
        borderSide: const BorderSide(color: Colors.red, width: 1.7),
      ),
    );
  }
}

class _LoginBottomWavePainter extends CustomPainter {
  const _LoginBottomWavePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Paint rearPaint = Paint()..color = const Color(0xFF72805A);

    final Path rearPath = Path()
      ..moveTo(0, size.height * 0.34)
      ..cubicTo(
        size.width * 0.20,
        size.height * 0.31,
        size.width * 0.32,
        size.height * 0.43,
        size.width * 0.49,
        size.height * 0.72,
      )
      ..cubicTo(
        size.width * 0.65,
        size.height * 0.95,
        size.width * 0.80,
        size.height * 0.42,
        size.width,
        size.height * 0.33,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(rearPath, rearPaint);

    final Paint frontPaint = Paint()..color = const Color(0xFF43532B);

    final Path frontPath = Path()
      ..moveTo(0, size.height * 0.26)
      ..cubicTo(
        size.width * 0.22,
        size.height * 0.25,
        size.width * 0.34,
        size.height * 0.39,
        size.width * 0.50,
        size.height * 0.78,
      )
      ..cubicTo(
        size.width * 0.65,
        size.height * 1.00,
        size.width * 0.77,
        size.height * 0.38,
        size.width,
        size.height * 0.26,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(frontPath, frontPaint);
  }

  @override
  bool shouldRepaint(covariant _LoginBottomWavePainter oldDelegate) {
    return false;
  }
}
